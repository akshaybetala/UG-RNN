function s = intersect(s1,s2)
r=member(s1,s2);
s=s1(r);

