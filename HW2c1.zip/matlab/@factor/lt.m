function f = lt(f,alpha)
% Element-wise less-than

f.t = double(f.t < alpha);


