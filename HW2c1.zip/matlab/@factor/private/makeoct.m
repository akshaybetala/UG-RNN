mkoctfile --mex vdiff.cpp 
mkoctfile --mex vintersect.cpp 
mkoctfile --mex vmember.cpp 
mkoctfile --mex vunion.cpp 
mkoctfile --mex vunionmemb.cpp 

