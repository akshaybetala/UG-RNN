function b = neq(f1,f2)
%  f~=g : test for non-equality of two factors (or a factor and scalar)

  b = ~(f1==f2);

