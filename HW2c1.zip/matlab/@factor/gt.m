function f = gt(f,alpha)
% Element-wise greater-than

f.t = double(f.t > alpha);


